<?php
define('HOST','52.41.167.226');
define('USER','toto');
define('PASS','TianhuanTu');
define('DB','TempForPhotoUploading');


